import React from 'react';
import { MapPin, Phone, Clock, Navigation, ExternalLink, ShieldCheck } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

export const LocationSection: React.FC = () => {
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    'Aakash Medical Store, Palhna, Lalganj, Azamgarh, Uttar Pradesh'
  )}`;

  return (
    <section id="visit-us" className="py-16 bg-slate-900 text-white relative overflow-hidden border-b border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
            <MapPin className="w-3.5 h-3.5" />
            <span>VISIT OUR PHARMACY</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display">
            Visit Us in <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 to-emerald-300">Palhna, Lalganj</span>
          </h2>
          <p className="text-sm sm:text-base text-slate-300">
            Conveniently located for local families, village residents, and visiting patients across Azamgarh district.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Location Info Card */}
          <div className="lg:col-span-5 bg-slate-800/90 backdrop-blur-md rounded-3xl border border-teal-500/30 p-6 sm:p-8 shadow-2xl flex flex-col justify-between space-y-6">
            <div className="space-y-6">
              
              <div className="border-b border-slate-700/80 pb-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400 block mb-1">AZAMGARH, UTTAR PRADESH</span>
                <h3 className="text-2xl font-extrabold text-white font-display">{STORE_INFO.name}</h3>
                <p className="text-xs text-slate-300 font-medium mt-1">{STORE_INFO.tagline}</p>
              </div>

              {/* Exact Address */}
              <div className="space-y-5">
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">STORE ADDRESS</span>
                    <p className="text-sm font-bold text-white mt-1">
                      {STORE_INFO.address.village}, {STORE_INFO.address.area}
                    </p>
                    <p className="text-xs text-slate-300">
                      {STORE_INFO.address.district}, {STORE_INFO.address.state}
                    </p>
                  </div>
                </div>

                {/* Phone Contact */}
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">CONTACT HOTLINE</span>
                    <p className="text-base font-bold text-white mt-1">
                      <a href={`tel:${STORE_INFO.phone}`} className="hover:text-teal-300 transition-colors">
                        +91 8303904690
                      </a>
                    </p>
                    <p className="text-xs text-slate-400">Calls and WhatsApp orders</p>
                  </div>
                </div>

                {/* Timings */}
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">STORE HOURS</span>
                    <p className="text-sm font-bold text-white mt-1">
                      Open Every Day: <span className="text-teal-300">7:00 AM – 10:00 PM</span>
                    </p>
                    <p className="text-xs text-slate-400">365 Days Open for Health Needs</p>
                  </div>
                </div>
              </div>

            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-slate-700/80 space-y-3">
              <a
                href={googleMapsUrl}
                target="_blank"
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-white font-bold text-xs shadow-md transition-all"
              >
                <Navigation className="w-4 h-4" />
                <span>Google Maps Directions</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

          </div>

          {/* Interactive Map Visual Box */}
          <div className="lg:col-span-7 bg-slate-950 rounded-3xl border border-slate-800 p-6 flex flex-col justify-between relative overflow-hidden min-h-[380px] shadow-2xl">
            
            {/* Visual Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 text-xs font-semibold">
              <span className="text-slate-300">PALHNA & LALGANJ REGION MAP</span>
              <span className="text-teal-400">PIN: 276202</span>
            </div>

            {/* Map View Box */}
            <div className="relative flex-1 bg-slate-900 rounded-2xl border border-slate-800 p-6 flex flex-col items-center justify-center text-center overflow-hidden">
              <div className="relative z-10 space-y-4 max-w-md">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-teal-500 to-emerald-500 text-white flex items-center justify-center mx-auto shadow-xl">
                  <MapPin className="w-7 h-7" />
                </div>

                <div>
                  <h4 className="text-lg font-bold text-white font-display">Aakash Medical Store</h4>
                  <p className="text-xs text-teal-300 font-medium mt-1">Palhna Main Market, Lalganj Road, Azamgarh, UP</p>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-300 text-left space-y-1.5">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-teal-400 mb-1">KEY LANDMARKS & ACCESSIBILITY:</p>
                  <p>• Central location near Palhna main market junction</p>
                  <p>• Easy parking for two-wheelers and vehicles</p>
                  <p>• Quick counter dispatch for local village families</p>
                </div>

                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-md transition-all"
                >
                  <span>Open Maps Navigation</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Local Trust Note */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2 font-semibold">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-teal-400" />
                <span>PALHNA • LALGANJ • AZAMGARH</span>
              </span>
              <span className="text-teal-400 font-bold">+91 8303904690</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};


