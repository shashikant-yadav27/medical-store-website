import React from 'react';
import { Phone, MessageCircle, Pill } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

interface FloatingCallWidgetProps {
  onOpenOrderModal: () => void;
}

export const FloatingCallWidget: React.FC<FloatingCallWidgetProps> = ({ onOpenOrderModal }) => {
  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col gap-2 items-end">
      
      {/* WhatsApp Button */}
      <a
        href={`https://wa.me/${STORE_INFO.whatsapp}?text=Hello%20Aakash%20Medical%20Store%2C%20I%20want%20to%20order%20medicines`}
        target="_blank"
        rel="noreferrer"
        className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold micro-label py-2.5 px-4 shadow-xl border-2 border-slate-900 transition-transform hover:-translate-y-0.5"
        title="WhatsApp Order"
      >
        <MessageCircle className="w-4 h-4" />
        <span className="hidden xs:inline">WHATSAPP ORDER</span>
      </a>

      {/* Direct Call Button */}
      <a
        href={`tel:${STORE_INFO.phone}`}
        className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold micro-label py-2.5 px-4 shadow-xl border-2 border-slate-900 transition-transform hover:-translate-y-0.5"
        title="Call 8303904690"
      >
        <Phone className="w-4 h-4" />
        <span>CALL: 8303904690</span>
      </a>

      {/* Quick Order Button */}
      <button
        onClick={onOpenOrderModal}
        className="flex items-center gap-2 bg-slate-900 text-white font-bold micro-label py-2 px-3.5 border-2 border-slate-900 shadow-lg cursor-pointer hover:bg-slate-800"
      >
        <Pill className="w-3.5 h-3.5 text-blue-400" />
        <span>PRESCRIPTION ORDER</span>
      </button>

    </div>
  );
};

