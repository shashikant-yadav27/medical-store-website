import React, { useState } from 'react';
import { Search, Pill, FileText, Activity, Heart, Stethoscope, Cross, MessageCircle, ArrowRight, Upload } from 'lucide-react';
import { CATEGORIES, POPULAR_PRODUCTS, STORE_INFO } from '../data/medicalData';

interface CategoryCatalogProps {
  onOpenOrderModal: (medicineName?: string) => void;
}

export const CategoryCatalog: React.FC<CategoryCatalogProps> = ({ onOpenOrderModal }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'FileText':
        return <FileText className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Pill':
        return <Pill className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Activity':
        return <Activity className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Heart':
        return <Heart className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Stethoscope':
        return <Stethoscope className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      default:
        return <Cross className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
    }
  };

  const filteredProducts = POPULAR_PRODUCTS.filter((product) => {
    const matchesCategory =
      selectedCategory === 'all' || product.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.purpose.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="categories" className="py-16 bg-slate-50/50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800/60">
            <Pill className="w-3.5 h-3.5" />
            <span>CATEGORIES & CATALOG</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight font-display">
            Healthcare Products & <span className="text-teal-600 dark:text-teal-400">Available Medicines</span>
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300">
            Browse our essential pharmacy categories or quickly search for required medicines and healthcare supplies.
          </p>
        </div>

        {/* Categories Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {CATEGORIES.map((cat) => (
            <div
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`p-6 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between group ${
                selectedCategory === cat.id
                  ? 'border-teal-500 bg-white dark:bg-slate-800 ring-2 ring-teal-500/20 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/80 hover:border-teal-400 hover:shadow-md'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-11 h-11 rounded-2xl bg-teal-100 dark:bg-teal-950/80 flex items-center justify-center">
                    {getCategoryIcon(cat.iconName)}
                  </div>
                  {cat.badge && (
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-emerald-500 text-white shadow-xs">
                      {cat.badge}
                    </span>
                  )}
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white font-display">{cat.name}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{cat.description}</p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-700/80 flex items-center justify-between text-xs">
                <span className="text-slate-500 dark:text-slate-400 font-medium">{cat.itemCount}</span>
                <span className="text-teal-600 dark:text-teal-400 font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  <span>Explore</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Search & Popular Medicine Catalog Box */}
        <div className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 block mb-1">INSTANT INVENTORY FINDER</span>
              <h3 className="text-xl font-bold font-display text-slate-900 dark:text-white">
                Popular Medicines & Products
              </h3>
            </div>

            {/* Search Input */}
            <div className="relative min-w-[280px]">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search Paracetamol, BP monitor, vitamins..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white text-xs font-medium focus:outline-none focus:ring-2 focus:ring-teal-500/50"
              />
            </div>
          </div>

          {/* Filter Buttons */}
          <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 text-xs font-semibold">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2 rounded-xl cursor-pointer transition-all ${
                selectedCategory === 'all'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              All Items
            </button>
            <button
              onClick={() => setSelectedCategory('otc')}
              className={`px-4 py-2 rounded-xl cursor-pointer transition-all ${
                selectedCategory === 'otc'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              OTC & Daily Care
            </button>
            <button
              onClick={() => setSelectedCategory('supplements')}
              className={`px-4 py-2 rounded-xl cursor-pointer transition-all ${
                selectedCategory === 'supplements'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              Health & Wellness
            </button>
            <button
              onClick={() => setSelectedCategory('monitors')}
              className={`px-4 py-2 rounded-xl cursor-pointer transition-all ${
                selectedCategory === 'monitors'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              Monitors & Devices
            </button>
          </div>

          {/* Product Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-slate-50/80 dark:bg-slate-900/80 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 flex flex-col justify-between hover:border-teal-500/50 transition-all shadow-xs"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                      {product.brand}
                    </span>
                    {product.discount && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300">
                        {product.discount}
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 dark:text-white leading-tight font-display">
                    {product.name}
                  </h4>

                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    <strong className="text-slate-800 dark:text-slate-300 font-semibold">Use:</strong> {product.purpose}
                  </p>

                  <div className="pt-2 flex items-baseline gap-2">
                    <span className="text-base font-bold text-teal-600 dark:text-teal-400">
                      {product.price}
                    </span>
                    {product.originalPrice && (
                      <span className="text-xs text-slate-400 line-through">
                        {product.originalPrice}
                      </span>
                    )}
                  </div>
                </div>

                <div className="pt-4 mt-3 border-t border-slate-200/60 dark:border-slate-800 flex items-center gap-2">
                  <a
                    href={`https://wa.me/${STORE_INFO.whatsapp}?text=Hello%20Aakash%20Medical%20Store%2C%20I%20want%20to%20order%3A%20${encodeURIComponent(
                      product.name
                    )}%20(${product.price})`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>

                  <button
                    onClick={() => onOpenOrderModal(product.name)}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold cursor-pointer transition-colors"
                    title="Quick Order Form"
                  >
                    Request
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12 text-slate-500 space-y-2">
              <p className="text-sm font-medium">No direct match found for "{searchQuery}".</p>
              <p className="text-xs">
                We carry all medicines in store! Call <a href={`tel:${STORE_INFO.phone}`} className="text-teal-600 dark:text-teal-400 font-bold underline">+91 8303904690</a> directly.
              </p>
            </div>
          )}

          {/* Prescription Reminder Box */}
          <div className="mt-8 bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white p-5 rounded-2xl border border-teal-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400 block mb-0.5">DOCTOR PRESCRIPTION UPLOAD</span>
                <p className="text-xs text-slate-200">
                  Take a clear picture of your doctor's prescription and upload or send directly on WhatsApp.
                </p>
              </div>
            </div>

            <button
              onClick={() => onOpenOrderModal('Doctor Prescription')}
              className="shrink-0 py-2.5 px-5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-white font-bold text-xs cursor-pointer shadow-md transition-all flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Prescription</span>
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};


