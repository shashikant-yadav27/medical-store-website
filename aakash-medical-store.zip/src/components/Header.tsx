import React, { useState } from 'react';
import { Phone, MessageCircle, Clock, MapPin, Menu, X, Pill, Cross } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

interface HeaderProps {
  onOpenOrderModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenOrderModal }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 shadow-xs transition-all">
      {/* Top Banner Strip */}
      <div className="bg-gradient-to-r from-teal-900 via-emerald-900 to-slate-900 text-slate-100 text-xs py-2 px-4 border-b border-teal-800/50">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-3 sm:gap-6 flex-wrap">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Open 7:00 AM – 10:00 PM</span>
            </span>
            <span className="hidden md:inline-flex items-center gap-1.5 text-slate-300 text-xs">
              <MapPin className="w-3.5 h-3.5 text-teal-400" />
              <span>{STORE_INFO.address.full}</span>
            </span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href={`tel:${STORE_INFO.phone}`}
              className="inline-flex items-center gap-1.5 font-bold text-teal-200 hover:text-white transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-teal-400" />
              <span>{STORE_INFO.phoneFormatted}</span>
            </a>
            <span className="text-teal-700/60 hidden xs:inline">|</span>
            <a
              href={`https://wa.me/${STORE_INFO.whatsapp}?text=Hello%20Aakash%20Medical%20Store%2C%20I%20want%20to%20inquire%20about%20medicines`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-emerald-300 hover:text-white transition-colors font-medium"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">WhatsApp Order</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
        {/* Logo & Brand Name */}
        <a href="#home" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-500 text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
            <Cross className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 px-2 py-0.5 rounded-full border border-teal-200/60 dark:border-teal-800/60">
                Palhna • Lalganj
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight font-display mt-0.5">
              Aakash <span className="text-teal-600 dark:text-teal-400 font-semibold">Medical Store</span>
            </h1>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1.5 p-1 bg-slate-100/80 dark:bg-slate-800/80 rounded-full border border-slate-200 dark:border-slate-700/60 text-xs font-semibold text-slate-700 dark:text-slate-200">
          <a href="#home" className="px-4 py-1.5 rounded-full hover:bg-white dark:hover:bg-slate-700 hover:text-teal-600 dark:hover:text-teal-300 transition-all">
            Home
          </a>
          <a href="#about" className="px-4 py-1.5 rounded-full hover:bg-white dark:hover:bg-slate-700 hover:text-teal-600 dark:hover:text-teal-300 transition-all">
            About Us
          </a>
          <a href="#offers" className="px-4 py-1.5 rounded-full text-emerald-600 dark:text-emerald-400 font-bold hover:bg-white dark:hover:bg-slate-700 transition-all flex items-center gap-1">
            <span>Offers</span>
            <span className="text-[10px] bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 px-1.5 py-0.2 rounded-full">20%</span>
          </a>
          <a href="#categories" className="px-4 py-1.5 rounded-full hover:bg-white dark:hover:bg-slate-700 hover:text-teal-600 dark:hover:text-teal-300 transition-all">
            Medicines
          </a>
          <a href="#why-choose-us" className="px-4 py-1.5 rounded-full hover:bg-white dark:hover:bg-slate-700 hover:text-teal-600 dark:hover:text-teal-300 transition-all">
            Why Choose Us
          </a>
          <a href="#visit-us" className="px-4 py-1.5 rounded-full hover:bg-white dark:hover:bg-slate-700 hover:text-teal-600 dark:hover:text-teal-300 transition-all">
            Visit Us
          </a>
        </nav>

        {/* Action CTA Buttons */}
        <div className="hidden sm:flex items-center gap-2.5">
          <a
            href={`tel:${STORE_INFO.phone}`}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-slate-300 dark:border-slate-700 font-bold text-xs text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Phone className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>Call Store</span>
          </a>
          <button
            onClick={onOpenOrderModal}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white px-5 py-2 rounded-full font-bold text-xs shadow-sm hover:shadow-md transition-all cursor-pointer"
          >
            <Pill className="w-4 h-4" />
            <span>Order Medicines</span>
          </button>
        </div>

        {/* Mobile Hamburger Toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          aria-label="Toggle Navigation Menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 py-4 space-y-3">
          <nav className="flex flex-col space-y-2 text-sm font-semibold text-slate-800 dark:text-slate-200">
            <a
              href="#home"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Home
            </a>
            <a
              href="#about"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              About Us
            </a>
            <a
              href="#offers"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-xl hover:bg-emerald-50 text-emerald-600 dark:hover:bg-slate-800 font-bold flex items-center justify-between"
            >
              <span>Special Offers</span>
              <span className="text-xs bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded-full">
                Up to 20% OFF
              </span>
            </a>
            <a
              href="#categories"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Medicines & Catalog
            </a>
            <a
              href="#why-choose-us"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Why Choose Us
            </a>
            <a
              href="#visit-us"
              onClick={() => setMobileMenuOpen(false)}
              className="py-2 px-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              📍 Visit Store (Palhna, Lalganj)
            </a>
          </nav>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenOrderModal();
              }}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-bold text-xs shadow-md"
            >
              <Pill className="w-4 h-4" />
              <span>Order Medicines Online</span>
            </button>
            <a
              href={`tel:${STORE_INFO.phone}`}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs"
            >
              <Phone className="w-4 h-4 text-teal-600" />
              <span>Call +91 8303904690</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};


