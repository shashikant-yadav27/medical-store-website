import React from 'react';
import { Heart, Stethoscope, Check, ArrowUpRight, ShieldCheck, Clock } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column Image Card Frame */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl bg-white dark:bg-slate-800 overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-700">
              <img
                src="/src/assets/images/healthcare_products_showcase_1786046192589.jpg"
                alt="Healthcare Products at Aakash Medical Store"
                referrerPolicy="no-referrer"
                className="w-full h-[380px] sm:h-[420px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/30 to-transparent" />
              
              <div className="absolute bottom-4 left-4 right-4 bg-slate-900/95 backdrop-blur-md p-4 rounded-2xl border border-slate-700 text-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-500 text-white flex items-center justify-center font-bold text-lg shrink-0">
                    <Heart className="w-5 h-5 fill-white" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400 block">PALHNA & LALGANJ</span>
                    <h4 className="text-xs font-bold text-white">Trusted Community Pharmacy</h4>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Authenticity Badge */}
            <div className="absolute -top-4 -left-4 bg-white dark:bg-slate-800 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 p-3.5 rounded-2xl shadow-xl hidden sm:flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-extrabold text-sm">
                100%
              </div>
              <div className="text-xs font-bold leading-tight">
                AUTHENTIC &<br />GENUINE PHARMA
              </div>
            </div>
          </div>

          {/* Right Column Copy & Core Services */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800/60 px-3.5 py-1 rounded-full text-xs font-bold text-teal-700 dark:text-teal-300">
              <Stethoscope className="w-3.5 h-3.5" />
              <span>ABOUT AAKASH MEDICAL STORE</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight font-display">
              Committed to Providing <span className="text-teal-600 dark:text-teal-400">Quality Healthcare</span> & Reliable Service
            </h2>

            {/* Quote Block */}
            <div className="bg-white dark:bg-slate-800/80 border-l-4 border-teal-500 p-5 rounded-r-2xl shadow-xs">
              <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 italic leading-relaxed">
                "Whether you need prescription medicines, over-the-counter products, health supplements, or personal care items, <strong className="text-slate-900 dark:text-white font-bold">Aakash Medical Store</strong> is committed to providing quality healthcare products with friendly and reliable service."
              </p>
            </div>

            {/* 4 Feature Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
              <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-xs">
                <div className="flex items-center gap-2 mb-1">
                  <Check className="w-4 h-4 text-emerald-500 stroke-[3]" />
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">Prescription Medicines</h3>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400">Doctor-prescribed authentic drugs from verified pharma distributors.</p>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-xs">
                <div className="flex items-center gap-2 mb-1">
                  <Check className="w-4 h-4 text-emerald-500 stroke-[3]" />
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">Over-The-Counter Care</h3>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400">Quick relief medicines for fever, cold, acidity, and pain relief.</p>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-xs">
                <div className="flex items-center gap-2 mb-1">
                  <Check className="w-4 h-4 text-emerald-500 stroke-[3]" />
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">Health Supplements</h3>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400">Multivitamins, Calcium, Protein powders, & herbal health products.</p>
              </div>

              <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-xs">
                <div className="flex items-center gap-2 mb-1">
                  <Check className="w-4 h-4 text-emerald-500 stroke-[3]" />
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">Personal & Baby Care</h3>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400">Skincare, hygiene items, baby lotions, diapers & essentials.</p>
              </div>
            </div>

            {/* Address Callout Banner */}
            <div className="pt-2 flex items-center justify-between bg-gradient-to-r from-slate-900 to-teal-950 text-white p-5 rounded-2xl border border-teal-500/30">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400 block mb-1">STORE LOCATION</span>
                <p className="text-xs sm:text-sm font-bold">{STORE_INFO.address.full}</p>
              </div>
              <a
                href="#visit-us"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-500 px-4 py-2 rounded-xl transition-colors shrink-0"
              >
                <span>Find Store</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};


