import React from 'react';
import { MapPin, Phone, Heart, Cross, Clock } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t-2 border-slate-900 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
          
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-blue-600 text-white flex items-center justify-center font-bold">
                <Cross className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-bold text-white font-serif uppercase tracking-wider">{STORE_INFO.name}</h3>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Your community pharmacy in Palhna, Lalganj, Azamgarh. Providing authentic prescription medicines, OTC items, and medical monitors with integrity.
            </p>

            <div className="inline-flex items-center gap-1.5 micro-label text-blue-400 bg-slate-900 border border-slate-800 px-3 py-1">
              <Heart className="w-3.5 h-3.5 fill-blue-500 text-blue-500" />
              <span>QUALITY & CARE GUARANTEED</span>
            </div>
          </div>

          {/* Contact Details */}
          <div className="space-y-3">
            <h4 className="micro-label text-white border-b border-slate-800 pb-2">
              CONTACT & LOCATION
            </h4>
            
            <div className="space-y-3 text-xs">
              <div className="flex items-start gap-2.5 text-slate-300">
                <MapPin className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>{STORE_INFO.address.full}</span>
              </div>

              <div className="flex items-center gap-2.5 text-slate-300">
                <Phone className="w-4 h-4 text-blue-400 shrink-0" />
                <span><a href={`tel:${STORE_INFO.phone}`} className="font-bold text-white hover:text-blue-400">{STORE_INFO.phoneFormatted}</a></span>
              </div>

              <div className="flex items-center gap-2.5 text-slate-300">
                <Clock className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Open Daily: 7:00 AM – 10:00 PM</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="micro-label text-white border-b border-slate-800 pb-2">
              QUICK NAVIGATION
            </h4>
            <ul className="space-y-2 text-xs micro-label">
              <li>
                <a href="#home" className="hover:text-blue-400 transition-colors">HOME PAGE</a>
              </li>
              <li>
                <a href="#about" className="hover:text-blue-400 transition-colors">ABOUT PHARMACY</a>
              </li>
              <li>
                <a href="#offers" className="text-blue-400 font-bold hover:underline">SPECIAL OFFERS</a>
              </li>
              <li>
                <a href="#categories" className="hover:text-blue-400 transition-colors">MEDICINE CATALOG</a>
              </li>
              <li>
                <a href="#why-choose-us" className="hover:text-blue-400 transition-colors">WHY CHOOSE US</a>
              </li>
              <li>
                <a href="#visit-us" className="hover:text-blue-400 transition-colors">VISIT STORE</a>
              </li>
            </ul>
          </div>

          {/* Emergency Box */}
          <div className="bg-slate-900 p-5 border border-slate-800 space-y-3">
            <span className="micro-label text-blue-400 block">EMERGENCY HOTLINE</span>
            <p className="text-xs text-slate-300">
              Need medicines delivered or reserved urgently in Palhna or Lalganj?
            </p>
            <a
              href={`tel:${STORE_INFO.phone}`}
              className="block w-full py-2.5 px-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-widest text-center transition-colors"
            >
              Call +91 8303904690
            </a>
            <a
              href={`https://wa.me/${STORE_INFO.whatsapp}?text=Hello%20Aakash%20Medical%20Store`}
              target="_blank"
              rel="noreferrer"
              className="block w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase tracking-wider text-center border border-slate-700 transition-colors"
            >
              WhatsApp Support
            </a>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3 micro-label">
          <div>
            <span>© {new Date().getFullYear()} AAKASH MEDICAL STORE. ALL RIGHTS RESERVED.</span>
          </div>

          <div className="text-slate-400 text-center sm:text-right">
            <span>PALHNA, LALGANJ, AZAMGARH • TEL: +91 8303904690</span>
          </div>
        </div>

        {/* Medical Disclaimer */}
        <div className="mt-4 pt-3 border-t border-slate-900 text-[11px] text-slate-600 text-center">
          * Prescription drugs are dispensed strictly against a valid doctor's prescription in accordance with Indian pharmacy regulations.
        </div>

      </div>
    </footer>
  );
};

