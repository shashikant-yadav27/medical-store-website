import React from 'react';
import { Sparkles, Truck, Pill, ArrowRight, Gift } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

interface OfferBannerProps {
  onOpenOrderModal: () => void;
}

export const OfferBanner: React.FC<OfferBannerProps> = ({ onOpenOrderModal }) => {
  return (
    <section id="offers" className="py-12 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-teal-900 via-slate-900 to-emerald-950 text-white p-8 sm:p-10 md:p-12 rounded-3xl border border-teal-500/20 shadow-xl relative overflow-hidden">
          
          {/* Subtle decorative circles */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            
            {/* Offer Text Content */}
            <div className="lg:col-span-8 space-y-4 text-left">
              <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3.5 py-1 rounded-full text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
                <span>SPECIAL HEALTHCARE OFFERS</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-display">
                Save Up to <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 to-emerald-300">20% OFF</span> on Selected Healthcare Supplies
              </h2>

              <div className="space-y-2">
                <p className="text-sm sm:text-base text-slate-200 flex items-center gap-2">
                  <Pill className="w-4 h-4 text-teal-400 shrink-0" />
                  <span>Quality healthcare products & prescription medicines at special community prices.</span>
                </p>
                <p className="text-sm text-slate-300 flex items-center gap-2">
                  <Truck className="w-4 h-4 text-teal-400 shrink-0" />
                  <span>Prompt fulfillment and local delivery support in Palhna & Lalganj.</span>
                </p>
              </div>

              <div className="pt-2 flex flex-wrap items-center gap-2.5 text-xs font-semibold text-slate-200">
                <span className="bg-slate-800/80 border border-slate-700/80 px-3 py-1 rounded-full">✔ FREE DOSAGE COUNSELING</span>
                <span className="bg-slate-800/80 border border-slate-700/80 px-3 py-1 rounded-full">✔ GENUINE PHARMA GUARANTEE</span>
                <span className="bg-slate-800/80 border border-slate-700/80 px-3 py-1 rounded-full">✔ CHRONIC CARE SAVINGS</span>
              </div>
            </div>

            {/* Offer Card Badge & Action Buttons */}
            <div className="lg:col-span-4 flex flex-col items-center justify-center">
              <div className="w-full bg-slate-800/90 backdrop-blur-md p-6 rounded-2xl border border-teal-500/30 text-center space-y-4 shadow-xl">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-teal-500 to-emerald-500 text-white font-display font-extrabold text-2xl shadow-md">
                  20%
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Save on Health Supplies</h3>
                  <p className="text-xs text-slate-400 mt-1">Claim discount in-store or on WhatsApp</p>
                </div>

                <div className="pt-1 flex flex-col gap-2.5">
                  <button
                    onClick={onOpenOrderModal}
                    className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-white font-bold text-xs transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>Claim Discount Now</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <a
                    href={`https://wa.me/${STORE_INFO.whatsapp}?text=Hello%20Aakash%20Medical%20Store%2C%20I%20want%20to%20avail%20the%20Special%20Healthcare%20Offer%20(Up%20to%2020%25%20OFF)`}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 px-3 rounded-xl text-xs font-bold text-emerald-300 bg-slate-900 border border-slate-700 hover:bg-slate-950 transition-colors"
                  >
                    Send WhatsApp Query
                  </a>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};


