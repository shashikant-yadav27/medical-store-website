import React from 'react';
import { Phone, MessageCircle, AlertCircle, Zap } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

export const EmergencyBanner: React.FC = () => {
  return (
    <section className="bg-gradient-to-r from-teal-700 via-emerald-600 to-cyan-800 text-white shadow-md relative overflow-hidden">
      {/* Soft background light */}
      <div className="absolute -right-12 -bottom-12 w-56 h-56 bg-white/10 rounded-full blur-2xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-3.5">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          
          {/* Emergency Title & Info */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0 text-lg shadow-inner">
              🚑
            </div>
            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-white/20 text-white border border-white/30">
                  <Zap className="w-3 h-3 text-amber-300" /> Rapid Assistance
                </span>
                <span className="text-xs text-teal-100 font-medium hidden md:inline">
                  • Palhna, Lalganj & Surrounding Villages
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight mt-0.5">
                Need Medicines Urgently? We are here to help!
              </h2>
            </div>
          </div>

          {/* Action Call & WhatsApp Buttons */}
          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-center">
            <a
              href={`tel:${STORE_INFO.phone}`}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 bg-white text-teal-800 hover:bg-teal-50 px-4 py-2 rounded-full text-xs font-bold shadow-sm transition-all hover:scale-105"
            >
              <Phone className="w-3.5 h-3.5 text-teal-700 fill-teal-700" />
              <span>Call: 8303904690</span>
            </a>
            <a
              href={`https://wa.me/${STORE_INFO.whatsapp}?text=URGENT%20MEDICINE%20REQUEST%3A%20Hello%20Aakash%20Medical%20Store%2C%20I%20need%20urgent%20medicines.`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-white px-3.5 py-2 rounded-full text-xs font-bold shadow-sm transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp Urgent</span>
            </a>
          </div>

        </div>
      </div>
    </section>
  );
};

