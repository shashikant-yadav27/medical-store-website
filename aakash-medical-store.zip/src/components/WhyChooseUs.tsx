import React from 'react';
import { ShieldCheck, Headphones, Tag, Sparkles, Zap, Users, CheckCircle } from 'lucide-react';
import { STORE_INFO, WHY_CHOOSE_US } from '../data/medicalData';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Headphones':
        return <Headphones className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Tag':
        return <Tag className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Zap':
        return <Zap className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      case 'Users':
        return <Users className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
      default:
        return <CheckCircle className="w-5 h-5 text-teal-600 dark:text-teal-400" />;
    }
  };

  return (
    <section id="why-choose-us" className="py-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800/60">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>OUR COMMITMENT TO YOU</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight font-display">
            Why Choose <span className="text-teal-600 dark:text-teal-400">Aakash Medical Store</span>?
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300">
            We take pride in serving Palhna, Lalganj, and surrounding Azamgarh families with authentic healthcare solutions, transparent pricing, and polite service.
          </p>
        </div>

        {/* 6 Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHY_CHOOSE_US.map((item) => (
            <div
              key={item.id}
              className="bg-slate-50/70 dark:bg-slate-800/80 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 hover:border-teal-500/50 dark:hover:border-teal-500/50 transition-all duration-200 flex flex-col justify-between group shadow-xs hover:shadow-md"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-11 h-11 rounded-2xl bg-teal-100 dark:bg-teal-950/80 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {getIcon(item.iconName)}
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/80 px-2.5 py-0.5 rounded-full border border-teal-200/60 dark:border-teal-800/60">
                    VERIFIED
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white font-display">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                <span>AAKASH MEDICAL GUARANTEE</span>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action Banner */}
        <div className="mt-12 bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white p-8 rounded-3xl border border-teal-500/30 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400 block mb-1">NEED HELP FINDING A MEDICINE?</span>
            <h4 className="text-lg font-bold text-white font-display">Have a specific medicine requirement or doctor prescription?</h4>
            <p className="text-xs text-slate-300">
              Call us directly at <span className="text-teal-300 font-bold">{STORE_INFO.phoneFormatted}</span> or send a photo on WhatsApp.
            </p>
          </div>
          <a
            href={`tel:${STORE_INFO.phone}`}
            className="shrink-0 px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-white font-bold text-xs shadow-md transition-all"
          >
            Call Store Now
          </a>
        </div>

      </div>
    </section>
  );
};


