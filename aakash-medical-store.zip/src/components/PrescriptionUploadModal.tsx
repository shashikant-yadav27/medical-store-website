import React, { useState } from 'react';
import { X, Pill, Phone, MessageCircle, CheckCircle, FileText } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefilledMedicine?: string;
}

export const PrescriptionUploadModal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  prefilledMedicine = '',
}) => {
  const [patientName, setPatientName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [medicines, setMedicines] = useState(prefilledMedicine);
  const [address, setAddress] = useState('Palhna / Lalganj Area');
  const [orderSubmitted, setOrderSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleWhatsAppSend = (e: React.FormEvent) => {
    e.preventDefault();
    const textMessage = `Hello Aakash Medical Store!%0A%0A*NEW MEDICINE ORDER REQUEST*%0A👤 *Name:* ${encodeURIComponent(
      patientName || 'Customer'
    )}%0A📞 *Phone:* ${encodeURIComponent(phoneNumber || 'Not provided')}%0A📍 *Location:* ${encodeURIComponent(
      address
    )}%0A💊 *Medicines / Request:* ${encodeURIComponent(medicines || prefilledMedicine || 'Prescription Order')}`;

    window.open(`https://wa.me/${STORE_INFO.whatsapp}?text=${textMessage}`, '_blank');
    setOrderSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border-2 border-slate-900 max-w-lg w-full p-6 shadow-2xl relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {!orderSubmitted ? (
          <form onSubmit={handleWhatsAppSend} className="space-y-4">
            <div className="flex items-center gap-3 border-b-2 border-slate-900 dark:border-slate-800 pb-3">
              <div className="w-10 h-10 bg-slate-900 text-white flex items-center justify-center font-bold">
                <Pill className="w-5 h-5" />
              </div>
              <div>
                <span className="micro-label text-blue-600 dark:text-blue-400 block mb-0.5">DIRECT ORDER FORM</span>
                <h3 className="text-lg font-bold font-serif uppercase text-slate-900 dark:text-white">Order Medicines Online</h3>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="micro-label text-slate-700 dark:text-slate-300 block mb-1">
                  FULL NAME
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rajesh Kumar"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full px-3.5 py-2 border-2 border-slate-900 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:outline-hidden focus:bg-white"
                />
              </div>

              <div>
                <label className="micro-label text-slate-700 dark:text-slate-300 block mb-1">
                  MOBILE PHONE NUMBER
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 9876543210"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-3.5 py-2 border-2 border-slate-900 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:outline-hidden focus:bg-white"
                />
              </div>

              <div>
                <label className="micro-label text-slate-700 dark:text-slate-300 block mb-1">
                  VILLAGE / LOCAL AREA
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. Palhna Market / Near Lalganj Hospital"
                  className="w-full px-3.5 py-2 border-2 border-slate-900 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:outline-hidden focus:bg-white"
                />
              </div>

              <div>
                <label className="micro-label text-slate-700 dark:text-slate-300 block mb-1">
                  MEDICINE NAMES & DOSAGE
                </label>
                <textarea
                  rows={3}
                  required
                  value={medicines}
                  onChange={(e) => setMedicines(e.target.value)}
                  placeholder="List your required medicines or type 'Doctor Prescription Attached'"
                  className="w-full px-3.5 py-2 border-2 border-slate-900 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:outline-hidden focus:bg-white"
                />
              </div>

              <div className="bg-slate-900 text-white p-3 border border-slate-800 text-xs flex items-start gap-2">
                <FileText className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span className="text-[11px] leading-tight text-slate-300">
                  Tip: When WhatsApp opens, attach a picture of your doctor's prescription directly!
                </span>
              </div>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                type="submit"
                className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send Order to WhatsApp (+91 8303904690)</span>
              </button>

              <a
                href={`tel:${STORE_INFO.phone}`}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 font-bold text-xs uppercase tracking-wider text-center flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-blue-600" />
                <span>Call Store: +91 8303904690</span>
              </a>
            </div>
          </form>
        ) : (
          <div className="text-center py-8 space-y-4">
            <div className="w-14 h-14 bg-emerald-600 text-white flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8" />
            </div>
            <div>
              <span className="micro-label text-blue-600 block mb-1">SUCCESSFULLY SENT</span>
              <h3 className="text-xl font-bold font-serif uppercase text-slate-900 dark:text-white">Order Sent to WhatsApp!</h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 max-w-xs mx-auto">
                Thank you, {patientName || 'valued customer'}. Aakash Medical Store will confirm your order details shortly.
              </p>
            </div>
            <button
              onClick={() => {
                setOrderSubmitted(false);
                onClose();
              }}
              className="py-2.5 px-6 font-bold text-xs uppercase tracking-widest bg-slate-900 text-white dark:bg-white dark:text-slate-900 cursor-pointer"
            >
              Close Window
            </button>
          </div>
        )}

      </div>
    </div>
  );
};

