import React, { useState } from 'react';
import { Pill, Phone, ShieldCheck, Truck, UserCheck, HeartHandshake, ArrowRight, MapPin, Search, Upload, CheckCircle2 } from 'lucide-react';
import { STORE_INFO } from '../data/medicalData';

interface HeroSectionProps {
  onOpenOrderModal: (medicineName?: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenOrderModal }) => {
  const [quickSearch, setQuickSearch] = useState('');

  const handleQuickSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickSearch.trim()) {
      onOpenOrderModal(quickSearch.trim());
    } else {
      onOpenOrderModal();
    }
  };

  return (
    <section id="home" className="relative bg-gradient-to-b from-slate-900 via-teal-950 to-slate-900 text-white overflow-hidden py-12 sm:py-16 lg:py-20">
      {/* Background Soft Glow circles */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-10 right-10 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Main Hero Copy & Search Bar */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Location Pill Badge */}
            <div className="inline-flex items-center gap-2 bg-teal-500/15 border border-teal-500/30 px-3.5 py-1.5 rounded-full text-xs font-semibold text-teal-200">
              <MapPin className="w-3.5 h-3.5 text-teal-400" />
              <span>Palhna, Lalganj • Azamgarh, UP</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span className="text-emerald-300 font-bold">100% Verified Pharmacy</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-tight font-display">
              Your Health & Pharmacy Partner in <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-emerald-300 to-cyan-200">Palhna, Lalganj</span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Order authentic prescription drugs, over-the-counter medicines, health monitors, and daily supplements with direct WhatsApp ordering or quick store pickup.
            </p>

            {/* Quick Medicine Search Box */}
            <form onSubmit={handleQuickSearchSubmit} className="bg-white/10 dark:bg-slate-800/80 p-2 rounded-2xl border border-white/20 backdrop-blur-md max-w-xl shadow-2xl flex items-center gap-2">
              <div className="pl-3 text-teal-300">
                <Search className="w-5 h-5" />
              </div>
              <input
                type="text"
                placeholder="Search medicine name (e.g. Paracetamol, BP monitor)..."
                value={quickSearch}
                onChange={(e) => setQuickSearch(e.target.value)}
                className="w-full bg-transparent text-white placeholder-slate-400 text-xs sm:text-sm focus:outline-none px-2 py-1.5"
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all shadow-md shrink-0 cursor-pointer flex items-center gap-1.5"
              >
                <span>Order</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Primary Action Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => onOpenOrderModal()}
                className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white px-6 py-3 rounded-xl font-bold text-xs shadow-lg hover:shadow-emerald-500/20 transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Upload Doctor Prescription</span>
              </button>

              <a
                href={`tel:${STORE_INFO.phone}`}
                className="inline-flex items-center gap-2 bg-slate-800/90 hover:bg-slate-700/90 text-white border border-slate-700 px-5 py-3 rounded-xl font-bold text-xs transition-all"
              >
                <Phone className="w-4 h-4 text-teal-400" />
                <span>Call Store: +91 8303904690</span>
              </a>
            </div>

            {/* Micro Guarantees */}
            <div className="pt-2 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-slate-300">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>100% Genuine Pharma</span>
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Fast Palhna & Lalganj Service</span>
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Verified Pharmacists</span>
              </span>
            </div>

          </div>

          {/* Right Column Interactive Prescription Glass Card */}
          <div className="lg:col-span-5">
            <div className="bg-slate-800/80 backdrop-blur-xl border border-teal-500/30 p-6 sm:p-7 rounded-3xl shadow-2xl space-y-6 relative">
              
              {/* Header inside card */}
              <div className="flex items-center justify-between border-b border-slate-700/80 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold">
                    <Pill className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Prescription & Medicine Order</h3>
                    <p className="text-[11px] text-slate-400">Direct WhatsApp Dispatch</p>
                  </div>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2.5 py-1 rounded-full">
                  Fast Response
                </span>
              </div>

              {/* Step Highlights */}
              <div className="space-y-3 text-xs">
                <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    1
                  </div>
                  <div>
                    <h4 className="font-bold text-white">List Medicines or Photo</h4>
                    <p className="text-slate-400 text-[11px] mt-0.5">Type required medicines or share a picture of your doctor's prescription.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    2
                  </div>
                  <div>
                    <h4 className="font-bold text-white">Instant WhatsApp Confirmation</h4>
                    <p className="text-slate-400 text-[11px] mt-0.5">Our pharmacists confirm stock, dosage, and price immediately.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-900/60 border border-slate-700/60">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    3
                  </div>
                  <div>
                    <h4 className="font-bold text-white">Pickup or Local Delivery</h4>
                    <p className="text-slate-400 text-[11px] mt-0.5">Collect at store counter in Palhna market or request home delivery.</p>
                  </div>
                </div>
              </div>

              {/* Send Prescription CTA */}
              <a
                href={`https://wa.me/${STORE_INFO.whatsapp}?text=Hello%20Aakash%20Medical%20Store%2C%20I%20want%20to%20send%20a%20prescription%20or%20order%20medicines`}
                target="_blank"
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition-all shadow-lg"
              >
                <span>📲 Send Prescription on WhatsApp (+91 8303904690)</span>
              </a>

            </div>
          </div>

        </div>
      </div>

      {/* Bottom Feature Badges Bar */}
      <div className="mt-12 border-t border-slate-800 bg-slate-950/80 py-4 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-4 text-xs font-semibold text-slate-300">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-teal-400" />
            <span>GENUINE & BRANDED MEDICINES</span>
          </div>
          <div className="flex items-center gap-2">
            <Truck className="w-4 h-4 text-teal-400" />
            <span>LOCAL PALHNA & LALGANJ FULFILLMENT</span>
          </div>
          <div className="flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-teal-400" />
            <span>KNOWLEDGEABLE HEALTHCARE STAFF</span>
          </div>
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-4 h-4 text-teal-400" />
            <span>FAIR & AFFORDABLE PRICING</span>
          </div>
        </div>
      </div>
    </section>
  );
};


