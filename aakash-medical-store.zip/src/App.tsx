import React, { useState } from 'react';
import { Header } from './components/Header';
import { EmergencyBanner } from './components/EmergencyBanner';
import { HeroSection } from './components/HeroSection';
import { OfferBanner } from './components/OfferBanner';
import { AboutSection } from './components/AboutSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { CategoryCatalog } from './components/CategoryCatalog';
import { LocationSection } from './components/LocationSection';
import { Testimonials } from './components/Testimonials';
import { Footer } from './components/Footer';
import { PrescriptionUploadModal } from './components/PrescriptionUploadModal';
import { FloatingCallWidget } from './components/FloatingCallWidget';

export default function App() {
  const [isOrderModalOpen, setIsOrderModalOpen] = useState<boolean>(false);
  const [prefilledMedicine, setPrefilledMedicine] = useState<string>('');

  const handleOpenOrderModal = (medicineName?: string) => {
    setPrefilledMedicine(medicineName || '');
    setIsOrderModalOpen(true);
  };

  const handleCloseOrderModal = () => {
    setIsOrderModalOpen(false);
    setPrefilledMedicine('');
  };

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {/* Sticky Top Header */}
      <Header onOpenOrderModal={() => handleOpenOrderModal()} />

      <main>
        {/* Emergency Alert Banner */}
        <EmergencyBanner />

        {/* Hero Section */}
        <HeroSection onOpenOrderModal={() => handleOpenOrderModal()} />

        {/* Special Offers Banner */}
        <OfferBanner onOpenOrderModal={() => handleOpenOrderModal('Special Healthcare Offer Item')} />

        {/* About Section */}
        <AboutSection />

        {/* Why Choose Us */}
        <WhyChooseUs />

        {/* Medicine Categories & Catalog */}
        <CategoryCatalog onOpenOrderModal={handleOpenOrderModal} />

        {/* Location & Visit Us */}
        <LocationSection />

        {/* Community Reviews & Testimonials */}
        <Testimonials />
      </main>

      {/* Footer */}
      <Footer />

      {/* Prescription & Order Modal */}
      <PrescriptionUploadModal
        isOpen={isOrderModalOpen}
        onClose={handleCloseOrderModal}
        prefilledMedicine={prefilledMedicine}
      />

      {/* Floating Action Call & WhatsApp Widget */}
      <FloatingCallWidget onOpenOrderModal={() => handleOpenOrderModal()} />
    </div>
  );
}
