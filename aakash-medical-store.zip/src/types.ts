export interface StoreInfo {
  name: string;
  tagline: string;
  phone: string;
  phoneFormatted: string;
  whatsapp: string;
  address: {
    village: string;
    area: string;
    district: string;
    state: string;
    full: string;
  };
  heroTitle: string;
  heroSubtitle: string;
  quote: string;
  offerHighlight: string;
  offerDetails: string;
  emergencyTitle: string;
  emergencySubtitle: string;
}

export interface FeaturePoint {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  iconName: string;
  itemCount: string;
  badge?: string;
}

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  brand: string;
  purpose: string;
  price: string;
  originalPrice?: string;
  discount?: string;
  inStock: boolean;
  requiresPrescription: boolean;
  popular?: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  rating: number;
  comment: string;
  date: string;
}
